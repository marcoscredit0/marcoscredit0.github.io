<!DOCTYPE html>
<meta http-equiv="content-type" content="text/html;charset=UTF-8"><style>
    .heading h3 {
        padding-left: 10px;
        color: #75111d;
        font-size: 25px;
        font-weight: 700;
        text-transform: uppercase;
        position: relative;
    }

    .heading h3:after {
        content: " ";
        background: #75111d;
        width: 362px;
        height: 5px;
        display: block;
        margin: 8px 0 -5px 0;
    }

    .heading h1 {
        padding-left: 10px;
        color: #75111d;
        font-size: 25px;
        font-weight: 700;
        text-transform: uppercase;
        position: relative;
    }

    .heading h1:after {
        content: " ";
        background: #75111d;
        width: 362px;
        height: 5px;
        display: block;
        margin: 8px 0 -5px 0;
    }

    .topbar {
        background: #221F20;
        line-height: 30px;
        padding: 8px 0;
    }

    .header {
        background: #ffffff;
        padding: 0px 0 0px 0;
    }

    .special-offers-row h3:after {
        content: " ";
        background: #75111d;
        width: 40px;
        height: 3px;
        margin-top: 17px;
        display: block;
    }

    .special-offers-row h1:after {
        content: " ";
        background: #75111d;
        width: 40px;
        height: 3px;
        margin-top: 17px;
        display: block;
    }

    .btn-supply {
        background: #75111d;
        line-height: 52px;
        padding: 0 20px;
        display: block;
        color: #fff;
        font-size: 14px;
        font-weight: 700;
        text-transform: uppercase;
    }

    .btn-supply:hover {
        background: #75111d;
        color: #fff;
    }

    .content h3 {
        margin-bottom: 23px;
        color: #75111d;
        font-size: 25px;
        font-weight: 700;
        text-transform: uppercase;
    }

    .contact-form h3:after {
        content: " ";
        background: #75111d;
        width: 40px;
        height: 3px;
        margin-top: 18px;
        display: block;
    }

    .product-info .price {
        border: 3px solid #75111d;
        line-height: 46px;
        display: block;
        color: #75111d;
        font-size: 17px;
        text-align: center;
    }

    .product-info .btn-submit:hover {
        background: #75111d;
    }

    .tab-nav li {
        border: 3px solid #75111d;
        width: 270px;
        float: left;
        text-align: center;
    }

    .tab-nav li a {
        line-height: 46px;
        display: block;
        color: #75111d;
        font-size: 14px;
        text-transform: uppercase;
    }

    .tab-nav li a:hover,
    .tab-nav li.active a {
        background: #75111d;
        color: #fff;
    }

    .special-offers-row .btn-more {
        background: #75111d;
        width: 270px;
        height: 52px;
        line-height: 52px;
        padding: 0 22px;
        margin-right: 22px;
        float: right;
        color: #fff;
        font-size: 14px;
        text-transform: uppercase;
    }

    .services li a:hover {
        color: #75111d;
    }

    .about h3 {
        padding-top: 10px;
        margin-bottom: 12px;
        color: #75111d;
        font-size: 25px;
        font-weight: 700;
        text-transform: uppercase;
    }

    .about .btn-submit:hover {
        background: #75111d;
    }

    .flex-direction-nav a:before {
        color: #75111d !important;
    }

    .bnone h1 {
        padding-left: 10px;
        color: #75111d;
        font-size: 25px;
        font-weight: 700;
        text-transform: uppercase;
        position: relative;
    }

    .content h1 {
        margin-bottom: 23px;
        color: #75111d;
        font-size: 25px;
        font-weight: 700;
        text-transform: uppercase;
    }

    .btn-submit {
        background: #75111d;
        border: none;
        width: 100%;
        line-height: 52px;
        display: block;
        color: #fff;
        font-size: 14px;
        font-weight: 700;
        text-transform: uppercase;
        text-align: center;
        cursor: pointer;
        -moz-transition: all 0.6s ease;
        -webkit-transition: all 0.6s ease;
        -ms-transition: all 0.6s ease;
        -o-transition: all 0.6s ease;
        transition: all 0.6s ease;
    }

    .btn-submit:hover {
        background: #75111d;
        color: #fff;
    }
</style>

<style>

.footer .top {
    background: #e0eff7;
    padding-bottom: 84px;
    padding-top: 28px;
}

.button.light-blue {
  background: #75111d;
    border-color: #75111d;
    color: #fff;
}

.tabpanel.border .nav-tabs > li.active > a, .tabpanel.border .nav-tabs > li.active > a:focus, .tabpanel.border .nav-tabs > li.active > a:hover {
    background: #FAFAFA;
    border: 1px solid #000000;
    border-bottom: 1px solid transparent;
    border-top: 2px solid transparent;
    color: #2e566e;
    opacity: 1;
    position: relative;
    margin-top: 10px;
}

.tabpanel.section-tab .nav-tabs > li.active > a, .tabpanel.section-tab .nav-tabs > li.active > a:focus, .tabpanel.section-tab .nav-tabs > li.active > a:hover {
    background: #090909;
    line-height: 34px;
    border: none;
    border-top: 4px solid #999999;
    color: #fff;
    opacity: 1;
    position: relative;
}
.section.dark > .inner {  background: #090909;  color: #fff; }

</style>



<head>
    <meta charset="UTF-8">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="title" content="">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta property="og:title" content="">
    <meta property="og:type" content="Website">
    <meta property="og:url" content="">
    <meta property="og:image" content="">
    <meta property="og:site_name" content="">
    <meta property="og:description" content="">
    <meta content="width=device-width, user-scalable=no" name="viewport">

    <link href="favicon.ico" rel="shortcut icon" />
    <link href="favicon.ico" rel="icon" />
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon" />

    <title>TIEPPO AUTOMÓVEIS</title>
    <div>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
            <div id="whatsapp">
            <a href="https://api.whatsapp.com/send?phone=5554999170167&text=Contato%20via%20Site%20da%20Loja" class="float whatsapp" target="_blank">
                <img src="https://www.tieppoautomoveis.com.br/images/whatsapp_animated.gif" class="fa fa-whatsapp my-float"></img>
            </a>
        </div>
    
            <!-- <a href="https://www.instagram.com/tieppoauto/" class="float instagram" target="_blank">
            <i class="fa fa-instagram my-float"></i>
        </a> -->
    </div>
<link rel="icon" type="image/png" href="https://www.tieppoautomoveis.com.br/img/favicon.png" />
<link href="https://www.tieppoautomoveis.com.br/css/bootstrap.css" rel="stylesheet" type="text/css">
<link href="https://www.tieppoautomoveis.com.br/css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="https://www.tieppoautomoveis.com.br/css/bootstrap-theme.css" rel="stylesheet" type="text/css">
<link href="https://www.tieppoautomoveis.com.br/css/bootstrap-multiselect.css" rel="stylesheet" type="text/css">
<link href="https://www.tieppoautomoveis.com.br/css/style.css" rel="stylesheet" type="text/css">
<link href="https://www.tieppoautomoveis.com.br/css/bootstrap-slider.css" rel="stylesheet" type="text/css">
<link href="https://www.tieppoautomoveis.com.br/css/pagination.css" rel="stylesheet" type="text/css">
<link href="https://www.tieppoautomoveis.com.br/css/slick-theme.html" rel="stylesheet" type="text/css">
<link href="https://www.tieppoautomoveis.com.br/css/colorbox.css" rel="stylesheet" type="text/css">
<link href="https://www.tieppoautomoveis.com.br/css/flexslider.css" rel="stylesheet" type="text/css">
<link href="https://www.tieppoautomoveis.com.br/fonts/cars/style.css" rel="stylesheet">    <base />
    <style>
        .slider {
            margin-bottom: 0px;
        }
    </style>
    <div id="fb-root"></div>
    <script>
        (function(d, s, id) {
            var js, fjs = d.getElementsByTagName(s)[0];
            if (d.getElementById(id)) return;
            js = d.createElement(s);
            js.id = id;
            js.src = "//connect.facebook.net/pt_BR/sdk.js#xfbml=1&version=v2.6";
            fjs.parentNode.insertBefore(js, fjs);
        }(document, 'script', 'facebook-jssdk'));
    </script>
</head>

<body class="home">

    <!--[if lt IE 7]>
	<p class="chromeframe">You are using an outdated browser. <a href="https://browsehappy.com/">Upgrade your browser today</a> or <a href="https://www.google.com/chromeframe/?redirect=true">install Google Chrome Frame</a> to better experience this site.</p>
<![endif]-->
    <!-- start header -->
    <header style="height: 40px; background: #75111d;">
        <!-- start container -->
        <div class="container">
            <!-- start row -->
            <div class="row">
                <div class="col-md-12">
                    <div align="right" class="web" style="color: white;padding: 10px;">
                        Segunda a Sábado
                                                    <a style="margin-left: 10px;color: white;" href="https://api.whatsapp.com/send?phone=5554999170167&text=Contato%20via%20Site%20da%20Loja" target="_blank">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-whatsapp" viewBox="0 0 24 24">
                                    <path d="M 12.011719 2 C 6.5057187 2 2.0234844 6.478375 2.0214844 11.984375 C 2.0204844 13.744375 2.4814687 15.462563 3.3554688 16.976562 L 2 22 L 7.2324219 20.763672 C 8.6914219 21.559672 10.333859 21.977516 12.005859 21.978516 L 12.009766 21.978516 C 17.514766 21.978516 21.995047 17.499141 21.998047 11.994141 C 22.000047 9.3251406 20.962172 6.8157344 19.076172 4.9277344 C 17.190172 3.0407344 14.683719 2.001 12.011719 2 z M 12.009766 4 C 14.145766 4.001 16.153109 4.8337969 17.662109 6.3417969 C 19.171109 7.8517969 20.000047 9.8581875 19.998047 11.992188 C 19.996047 16.396187 16.413812 19.978516 12.007812 19.978516 C 10.674812 19.977516 9.3544062 19.642812 8.1914062 19.007812 L 7.5175781 18.640625 L 6.7734375 18.816406 L 4.8046875 19.28125 L 5.2851562 17.496094 L 5.5019531 16.695312 L 5.0878906 15.976562 C 4.3898906 14.768562 4.0204844 13.387375 4.0214844 11.984375 C 4.0234844 7.582375 7.6067656 4 12.009766 4 z M 8.4765625 7.375 C 8.3095625 7.375 8.0395469 7.4375 7.8105469 7.6875 C 7.5815469 7.9365 6.9355469 8.5395781 6.9355469 9.7675781 C 6.9355469 10.995578 7.8300781 12.182609 7.9550781 12.349609 C 8.0790781 12.515609 9.68175 15.115234 12.21875 16.115234 C 14.32675 16.946234 14.754891 16.782234 15.212891 16.740234 C 15.670891 16.699234 16.690438 16.137687 16.898438 15.554688 C 17.106437 14.971687 17.106922 14.470187 17.044922 14.367188 C 16.982922 14.263188 16.816406 14.201172 16.566406 14.076172 C 16.317406 13.951172 15.090328 13.348625 14.861328 13.265625 C 14.632328 13.182625 14.464828 13.140625 14.298828 13.390625 C 14.132828 13.640625 13.655766 14.201187 13.509766 14.367188 C 13.363766 14.534188 13.21875 14.556641 12.96875 14.431641 C 12.71875 14.305641 11.914938 14.041406 10.960938 13.191406 C 10.218937 12.530406 9.7182656 11.714844 9.5722656 11.464844 C 9.4272656 11.215844 9.5585938 11.079078 9.6835938 10.955078 C 9.7955938 10.843078 9.9316406 10.663578 10.056641 10.517578 C 10.180641 10.371578 10.223641 10.267562 10.306641 10.101562 C 10.389641 9.9355625 10.347156 9.7890625 10.285156 9.6640625 C 10.223156 9.5390625 9.737625 8.3065 9.515625 7.8125 C 9.328625 7.3975 9.131125 7.3878594 8.953125 7.3808594 C 8.808125 7.3748594 8.6425625 7.375 8.4765625 7.375 z" />
                                </svg>
                            </a>
                                                                            <a style="color: white;" href="https://www.instagram.com/tieppoauto/" target="_blank">
                                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="currentColor" class="bi bi-instagram" viewBox="0 0 24 24">
                                    <path d="M 8 3 C 5.243 3 3 5.243 3 8 L 3 16 C 3 18.757 5.243 21 8 21 L 16 21 C 18.757 21 21 18.757 21 16 L 21 8 C 21 5.243 18.757 3 16 3 L 8 3 z M 8 5 L 16 5 C 17.654 5 19 6.346 19 8 L 19 16 C 19 17.654 17.654 19 16 19 L 8 19 C 6.346 19 5 17.654 5 16 L 5 8 C 5 6.346 6.346 5 8 5 z M 17 6 A 1 1 0 0 0 16 7 A 1 1 0 0 0 17 8 A 1 1 0 0 0 18 7 A 1 1 0 0 0 17 6 z M 12 7 C 9.243 7 7 9.243 7 12 C 7 14.757 9.243 17 12 17 C 14.757 17 17 14.757 17 12 C 17 9.243 14.757 7 12 7 z M 12 9 C 13.654 9 15 10.346 15 12 C 15 13.654 13.654 15 12 15 C 10.346 15 9 13.654 9 12 C 9 10.346 10.346 9 12 9 z" />
                                </svg>
                            </a>
                                                                            <a style="color: white;" href="https://www.facebook.com/tieppoautomoveis/" target="_blank">
                                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="currentColor" class="bi bi-facebook" viewBox="0 0 24 24">
                                    <path d="M 5 3 C 3.897 3 3 3.897 3 5 L 3 19 C 3 20.103 3.897 21 5 21 L 11.621094 21 L 14.414062 21 L 19 21 C 20.103 21 21 20.103 21 19 L 21 5 C 21 3.897 20.103 3 19 3 L 5 3 z M 5 5 L 19 5 L 19.001953 19 L 14.414062 19 L 14.414062 15.035156 L 16.779297 15.035156 L 17.130859 12.310547 L 14.429688 12.310547 L 14.429688 10.574219 C 14.429687 9.7862188 14.649297 9.2539062 15.779297 9.2539062 L 17.207031 9.2539062 L 17.207031 6.8222656 C 16.512031 6.7512656 15.814234 6.71675 15.115234 6.71875 C 13.041234 6.71875 11.621094 7.9845938 11.621094 10.308594 L 11.621094 12.314453 L 9.2773438 12.314453 L 9.2773438 15.039062 L 11.621094 15.039062 L 11.621094 19 L 5 19 L 5 5 z" />
                                </svg>
                            </a>
                                            </div>
                </div>
            </div>
            <!-- end row -->
        </div>
        <!-- end container -->
    </header>

    <!-- start header -->
    <header class="header clearfix">
        <!-- start container -->
        <div class="container">
            <!-- start row -->
            <div class="row">
                <div class="col-md-12">
                    <!-- start logo -->
                    <div class="logo">

                        <a href="index.php" title="TIEPPO AUTOMÓVEIS">

                            <img src="images/logo.png" alt="TIEPPO AUTOMÓVEIS">

                        </a>
                    </div>
                    <!-- end logo -->
                    <!-- start navigation -->
                    <nav class="navigation clearfix">
                        <ul>
                            
<!-- <li></li> -->
<li  class="" ><a href="home" title="Home">Home</a></li>
<li  class="" ><a href="sobre" title="Sobre Nós">Sobre Nós</a></li>
<li  class="" ><a href="nosso-estoque" title="Veículos">Veículos</a></li>
<li  class="" ><a href="fale-conosco" title="Contato">Contato</a></li>                        </ul>
                        <a href="javascript:;" class="menu-icon" title="Menu">Menu</a>
                    </nav>
                    <!-- end navigation -->
                </div>
            </div>
            <!-- end row -->
        </div>
        <!-- end container -->
    </header>
    <!-- start showcase -->
    <div class="showcase clearfix">

        <!-- start hero slider -->
        <div class="vid-cont">
            <video autoplay muted playsinline loop id="homepage-vid" class="homepage-vid" style="width: 100%; height: auto; visibility: visible;">
                <source src="https://www.tieppoautomoveis.com.br/images/capa.mp4" type="video/mp4">
                <!-- <img class="lozad" data-src="https://cdn.carswitch.com/assets/images/mobile-bg.jpg"> -->
            </video>
        </div>
    </div>
    <!-- end showcase -->
    <!-- start main container -->

    <section class="section dark tiny">
    <div class="inner">
        <div class="container">
            <div class="tabpanel border section-tab" role="tabpanel">
                <!-- <ul class="nav nav-tabs" role="tablist">
                    <li role="presentation" class="active"><a href="#search-cars" aria-controls="search-cars" role="tab" data-toggle="tab">Buscar</a></li>
                </ul> end .nav-tabs -->
                <div class="tab-content" style="background-color: #000;">

                    <div role="tabpanel" class="tab-pane fade  in active" id="search-cars">
                        <form action="https://www.tieppoautomoveis.com.br/buscar.php" class="banner-form" method="get">
                            <div class="item">
                                <div class="select-wrapper">
                                    <select class="selectpicker" id="marca" name="marca" style="height: 45px;">
                                        <option value="t">Marca do Veículo</option>
                                        <option value=" Fiat"> Fiat</option><option value=" Ford"> Ford</option><option value=" GM-Chevrolet"> GM-Chevrolet</option><option value=" Hyundai"> Hyundai</option><option value=" Jeep"> Jeep</option><option value=" Kia Motors"> Kia Motors</option><option value=" Mercedes-Benz"> Mercedes-Benz</option><option value=" Renault"> Renault</option><option value=" Toyota"> Toyota</option><option value=" Volkswagen"> Volkswagen</option>                                    </select>
                                    <span class="arrow"></span>
                                </div> <!-- end .select-wrapper -->
                            </div>

                            <div class="item">
                                <div class="select-wrapper">
                                    <input name="modelo" id="modelo" type="text" placeholder="Modelo" class="selectpicker" style="height: 45px; width: 100%; color: #75111d; !important">
                                    <span class="arrow"></span>
                                </div> <!-- end .select-wrapper -->
                            </div> <!-- end .item -->
                            <!-- end .item -->
                            <div class="item">
                                <button type="submit" class="button solid light-blue" style="height: 45px;     width: 100%;">Buscar</button>
                            </div> <!-- end .item -->
                        </form> <!-- end .banner-form -->
                    </div> <!-- end .tab-panel -->
                </div> <!-- end .tab-content -->
            </div> <!-- end .tabpanel -->
        </div> <!-- end .container -->
    </div> <!-- end .inner -->
</section> <!-- end .section -->
    
    <div class="main-container clearfix">
        <!-- start container -->
        <div class="container">
            <!-- start row -->
            <div class="row">
                <div class="col-md-12">
                    <div class="heading">
                        <h3>veículos em destaque</h3>
                    </div>
                    <!-- start car listing -->
                    <div class="car-listing clearfix">
                        <!-- start row -->
                        <div class="row clearfix">

                            <input type="hidden" id="current_page" />
                            <input type="hidden" id="show_per_page" />
                            <div id="content">

                                
                                    <!-- start ch car ........................................................................................................................... -->
                                    <div class="col-md-3 col-sm-6 used-cars-count">
                                        <!-- start car listing col -->
                                        <div class="car-listing-col clearfix">
                                            <!-- start imgb -->
                                            <div class="imgb">
                                                                                                <a href="veiculo/112484257/Carro-ONIX-PLUS-1.0T-LTZ-AT-2022">

                                                    
                                                    
                                                        <img src="https://www.negociecarros.com.br/fotos_g/707390188.jpeg" alt="ONIX PLUS 1.0T LTZ AT - 2022" width="100%">

                                                    

                                                </a>
                                            </div>

                                            <!-- end imgb -->
                                            <!-- start txtb -->
                                            <div class="txtb semi-info">
                                                <h3>
                                                    ONIX PLUS 1.0T LTZ AT                                                </h3>
                                                <ul class="clearfix">
                                                    <li>
                                                        <img src="images/ico_date.png" alt="date">
                                                        <span>
                                                            2022</span>
                                                    </li>
                                                                                                            <li>
                                                            <img src="images/ico_km.png" alt="km">
                                                            <span>
                                                                34.000 km</span>
                                                        </li>
                                                                                                    </ul>
                                                <strong class="price">
                                                    R$   97.900,00</strong>
                                            </div>
                                            <!-- end txtb -->

                                            <a href="veiculo/112484257/Carro-ONIX-PLUS-1.0T-LTZ-AT-2022" title="conferir veículo" class="btn-supply"><span>conferir veículo</span></a>
                                        </div>
                                        <!-- end car listing col -->
                                    </div>
                                    <!-- end ch car ........................................................................................................................... -->

                                
                                    <!-- start ch car ........................................................................................................................... -->
                                    <div class="col-md-3 col-sm-6 used-cars-count">
                                        <!-- start car listing col -->
                                        <div class="car-listing-col clearfix">
                                            <!-- start imgb -->
                                            <div class="imgb">
                                                                                                <a href="veiculo/112478754/Carro-DUSTER-1.6-CVT-INTENSE-2022">

                                                    
                                                    
                                                        <img src="https://www.negociecarros.com.br/fotos_g/542776632.jpeg" alt="DUSTER 1.6 CVT INTENSE - 2022" width="100%">

                                                    

                                                </a>
                                            </div>

                                            <!-- end imgb -->
                                            <!-- start txtb -->
                                            <div class="txtb semi-info">
                                                <h3>
                                                    DUSTER 1.6 CVT INTENSE                                                </h3>
                                                <ul class="clearfix">
                                                    <li>
                                                        <img src="images/ico_date.png" alt="date">
                                                        <span>
                                                            2022</span>
                                                    </li>
                                                                                                            <li>
                                                            <img src="images/ico_km.png" alt="km">
                                                            <span>
                                                                17.000 km</span>
                                                        </li>
                                                                                                    </ul>
                                                <strong class="price">
                                                    R$   106.900,00</strong>
                                            </div>
                                            <!-- end txtb -->

                                            <a href="veiculo/112478754/Carro-DUSTER-1.6-CVT-INTENSE-2022" title="conferir veículo" class="btn-supply"><span>conferir veículo</span></a>
                                        </div>
                                        <!-- end car listing col -->
                                    </div>
                                    <!-- end ch car ........................................................................................................................... -->

                                
                                    <!-- start ch car ........................................................................................................................... -->
                                    <div class="col-md-3 col-sm-6 used-cars-count">
                                        <!-- start car listing col -->
                                        <div class="car-listing-col clearfix">
                                            <!-- start imgb -->
                                            <div class="imgb">
                                                                                                <a href="veiculo/112484665/Carro-ONIX-HATCH-1.0-T-AT-PREMIER-2021">

                                                    
                                                    
                                                        <img src="https://www.negociecarros.com.br/fotos_g/949438054.jpeg" alt="ONIX HATCH 1.0 T AT PREMIER - 2021" width="100%">

                                                    

                                                </a>
                                            </div>

                                            <!-- end imgb -->
                                            <!-- start txtb -->
                                            <div class="txtb semi-info">
                                                <h3>
                                                    ONIX HATCH 1.0 T AT PREMIER                                                </h3>
                                                <ul class="clearfix">
                                                    <li>
                                                        <img src="images/ico_date.png" alt="date">
                                                        <span>
                                                            2021</span>
                                                    </li>
                                                                                                            <li>
                                                            <img src="images/ico_km.png" alt="km">
                                                            <span>
                                                                34.000 km</span>
                                                        </li>
                                                                                                    </ul>
                                                <strong class="price">
                                                    R$   96.900,00</strong>
                                            </div>
                                            <!-- end txtb -->

                                            <a href="veiculo/112484665/Carro-ONIX-HATCH-1.0-T-AT-PREMIER-2021" title="conferir veículo" class="btn-supply"><span>conferir veículo</span></a>
                                        </div>
                                        <!-- end car listing col -->
                                    </div>
                                    <!-- end ch car ........................................................................................................................... -->

                                
                                    <!-- start ch car ........................................................................................................................... -->
                                    <div class="col-md-3 col-sm-6 used-cars-count">
                                        <!-- start car listing col -->
                                        <div class="car-listing-col clearfix">
                                            <!-- start imgb -->
                                            <div class="imgb">
                                                                                                <a href="veiculo/112475002/Carro-SPIN-1.8-ACTIV-AUTOMÁTICA-2019">

                                                    
                                                    
                                                        <img src="https://www.negociecarros.com.br/fotos_g/161655014.jpeg" alt="SPIN 1.8 ACTIV AUTOM�TICA - 2019" width="100%">

                                                    

                                                </a>
                                            </div>

                                            <!-- end imgb -->
                                            <!-- start txtb -->
                                            <div class="txtb semi-info">
                                                <h3>
                                                    SPIN 1.8 ACTIV AUTOMÁTICA                                                </h3>
                                                <ul class="clearfix">
                                                    <li>
                                                        <img src="images/ico_date.png" alt="date">
                                                        <span>
                                                            2019</span>
                                                    </li>
                                                                                                            <li>
                                                            <img src="images/ico_km.png" alt="km">
                                                            <span>
                                                                42.000 km</span>
                                                        </li>
                                                                                                    </ul>
                                                <strong class="price">
                                                    R$   85.900,00</strong>
                                            </div>
                                            <!-- end txtb -->

                                            <a href="veiculo/112475002/Carro-SPIN-1.8-ACTIV-AUTOMÁTICA-2019" title="conferir veículo" class="btn-supply"><span>conferir veículo</span></a>
                                        </div>
                                        <!-- end car listing col -->
                                    </div>
                                    <!-- end ch car ........................................................................................................................... -->

                                

                            </div>
                            <!-- end row -->
                        </div>
                        <div id="page_navigation"></div>
                        <!-- end car listing -->

                    </div>
                </div>
                <!-- end row -->
            </div>
            <!-- end container -->
        </div>
        <!-- end main container -->
        <footer class="footer">
            <div class="row" style="width: 85%;display: block;margin-bottom: 40px;margin-left: 5%;">
            <div class="heading">
                <h3>Nossa Localização</h3>
            </div>
            <div class="col-sm-12">
                <!-- <h5>Onde Estamos</h5> -->

                <iframe src='https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3526.2946219652936!2d-52.225117084933714!3d-27.892930782715354!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94fc2d6ea4f6cf6d%3A0x63aa3724fa76f6a7!2sTieppo%20Autom%C3%B3veis!5e0!3m2!1spt-BR!2sbr!4v1674643172021!5m2!1spt-BR!2sbr' width='100%' height='300' frameborder='0' style='border:0' allowfullscreen></iframe>            </div>
        </div>
    

    <!-- start footer bottom -->
    <div class="footer-bottom clearfix">
        <!-- start container -->
        <div class="container">
            <!-- start row -->
            <div class="row">
                <div class="col-md-12">
                    <!-- start row -->
                    <div class="row clearfix">
                        <div class="col-md-4">
                            <!-- start footer links -->
                            <div class="footer-links clearfix">
                                <h5>acesso rápido</h5>
                                <ul>
                                    
<!-- <li></li> -->
<li  class="" ><a href="home" title="Home">Home</a></li>
<li  class="" ><a href="sobre" title="Sobre Nós">Sobre Nós</a></li>
<li  class="" ><a href="nosso-estoque" title="Veículos">Veículos</a></li>
<li  class="" ><a href="fale-conosco" title="Contato">Contato</a></li>                                </ul>
                            </div>
                            <!-- end footer links -->
                        </div>



                                                    <div class="col-md-4">
                                <h5>facebook</h5>

                                <div class="map">



                                    <div class="fb-like-box" data-href="https://www.facebook.com/tieppoautomoveis/" data-width="100%" data-height="150" data-show-faces="true" data-stream="false" data-header="true">
                                    </div>


                                    <div class="fb-page" data-href="https://www.facebook.com/tieppoautomoveis/" data-tabs="timeline" data-height="150" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true">
                                        <div class="fb-xfbml-parse-ignore">
                                            <blockquote cite="https://www.facebook.com/tieppoautomoveis/">
                                                <a href="https://www.facebook.com/tieppoautomoveis/">TIEPPO AUTOMÓVEIS</a>
                                            </blockquote>
                                        </div>
                                    </div>



                                </div>

                            </div>
                        
                        <div class="col-md-4">
                            <!-- start contact details -->
                            <div class="contact-details clearfix">
                                <h5>fale conosco</h5>
                                <div class="map">
                                    <address>
                                        Rua Pedro Toniollo, 240 <br> Sala 1 CENTRO - Getúlio Vargas / RS                                        <span class="phone">(54) 3341-4114 | (54) 3341-3160</span> <br>
                                        rafaeltieppo@bol.com.br                                    </address>
                                </div>
                            </div>
                            <!-- end contact details -->
                        </div>
                    </div>
                    <!-- end row -->
                    <!-- start footer bottom row
                    <div class="footer-bottom-row clearfix">
 
                        <div class="clearfix"></div>-->
                    <div align="right" class="web"><a href="https://www.negociecarros.com.br/" target="_blank" title="NegocieCarros">NegocieCarros</a></div>
                    <!--</div>
                     end footer bottom row -->
                </div>
            </div>
            <!-- end row -->
        </div>
        <!-- end container -->
    </div>
    <!-- end footer bottom -->
    <div style="height: 40px; background: #75111d;">
        <!-- start container -->
        <div class="container">
            <!-- start row -->
            <div class="row">
                <div class="col-md-12">
                    <div align="right" class="web" style="color: white;padding: 10px;">
                        Copyright 2023 | Todos os direitos reservados
                                                    <a style="margin-left: 10px;color: white;" href="https://api.whatsapp.com/send?phone=5554999170167&text=Contato%20via%20Site%20da%20Loja" target="_blank">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-whatsapp" viewBox="0 0 24 24">
                                    <path d="M 12.011719 2 C 6.5057187 2 2.0234844 6.478375 2.0214844 11.984375 C 2.0204844 13.744375 2.4814687 15.462563 3.3554688 16.976562 L 2 22 L 7.2324219 20.763672 C 8.6914219 21.559672 10.333859 21.977516 12.005859 21.978516 L 12.009766 21.978516 C 17.514766 21.978516 21.995047 17.499141 21.998047 11.994141 C 22.000047 9.3251406 20.962172 6.8157344 19.076172 4.9277344 C 17.190172 3.0407344 14.683719 2.001 12.011719 2 z M 12.009766 4 C 14.145766 4.001 16.153109 4.8337969 17.662109 6.3417969 C 19.171109 7.8517969 20.000047 9.8581875 19.998047 11.992188 C 19.996047 16.396187 16.413812 19.978516 12.007812 19.978516 C 10.674812 19.977516 9.3544062 19.642812 8.1914062 19.007812 L 7.5175781 18.640625 L 6.7734375 18.816406 L 4.8046875 19.28125 L 5.2851562 17.496094 L 5.5019531 16.695312 L 5.0878906 15.976562 C 4.3898906 14.768562 4.0204844 13.387375 4.0214844 11.984375 C 4.0234844 7.582375 7.6067656 4 12.009766 4 z M 8.4765625 7.375 C 8.3095625 7.375 8.0395469 7.4375 7.8105469 7.6875 C 7.5815469 7.9365 6.9355469 8.5395781 6.9355469 9.7675781 C 6.9355469 10.995578 7.8300781 12.182609 7.9550781 12.349609 C 8.0790781 12.515609 9.68175 15.115234 12.21875 16.115234 C 14.32675 16.946234 14.754891 16.782234 15.212891 16.740234 C 15.670891 16.699234 16.690438 16.137687 16.898438 15.554688 C 17.106437 14.971687 17.106922 14.470187 17.044922 14.367188 C 16.982922 14.263188 16.816406 14.201172 16.566406 14.076172 C 16.317406 13.951172 15.090328 13.348625 14.861328 13.265625 C 14.632328 13.182625 14.464828 13.140625 14.298828 13.390625 C 14.132828 13.640625 13.655766 14.201187 13.509766 14.367188 C 13.363766 14.534188 13.21875 14.556641 12.96875 14.431641 C 12.71875 14.305641 11.914938 14.041406 10.960938 13.191406 C 10.218937 12.530406 9.7182656 11.714844 9.5722656 11.464844 C 9.4272656 11.215844 9.5585938 11.079078 9.6835938 10.955078 C 9.7955938 10.843078 9.9316406 10.663578 10.056641 10.517578 C 10.180641 10.371578 10.223641 10.267562 10.306641 10.101562 C 10.389641 9.9355625 10.347156 9.7890625 10.285156 9.6640625 C 10.223156 9.5390625 9.737625 8.3065 9.515625 7.8125 C 9.328625 7.3975 9.131125 7.3878594 8.953125 7.3808594 C 8.808125 7.3748594 8.6425625 7.375 8.4765625 7.375 z" />
                                </svg>
                            </a>
                                                                            <a style="color: white;" href="https://www.instagram.com/tieppoauto/" target="_blank">
                                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="currentColor" class="bi bi-instagram" viewBox="0 0 24 24">
                                    <path d="M 8 3 C 5.243 3 3 5.243 3 8 L 3 16 C 3 18.757 5.243 21 8 21 L 16 21 C 18.757 21 21 18.757 21 16 L 21 8 C 21 5.243 18.757 3 16 3 L 8 3 z M 8 5 L 16 5 C 17.654 5 19 6.346 19 8 L 19 16 C 19 17.654 17.654 19 16 19 L 8 19 C 6.346 19 5 17.654 5 16 L 5 8 C 5 6.346 6.346 5 8 5 z M 17 6 A 1 1 0 0 0 16 7 A 1 1 0 0 0 17 8 A 1 1 0 0 0 18 7 A 1 1 0 0 0 17 6 z M 12 7 C 9.243 7 7 9.243 7 12 C 7 14.757 9.243 17 12 17 C 14.757 17 17 14.757 17 12 C 17 9.243 14.757 7 12 7 z M 12 9 C 13.654 9 15 10.346 15 12 C 15 13.654 13.654 15 12 15 C 10.346 15 9 13.654 9 12 C 9 10.346 10.346 9 12 9 z" />
                                </svg>
                            </a>
                                                                            <a style="color: white;" href="https://www.facebook.com/tieppoautomoveis/" target="_blank">
                                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="currentColor" class="bi bi-facebook" viewBox="0 0 24 24">
                                    <path d="M 5 3 C 3.897 3 3 3.897 3 5 L 3 19 C 3 20.103 3.897 21 5 21 L 11.621094 21 L 14.414062 21 L 19 21 C 20.103 21 21 20.103 21 19 L 21 5 C 21 3.897 20.103 3 19 3 L 5 3 z M 5 5 L 19 5 L 19.001953 19 L 14.414062 19 L 14.414062 15.035156 L 16.779297 15.035156 L 17.130859 12.310547 L 14.429688 12.310547 L 14.429688 10.574219 C 14.429687 9.7862188 14.649297 9.2539062 15.779297 9.2539062 L 17.207031 9.2539062 L 17.207031 6.8222656 C 16.512031 6.7512656 15.814234 6.71675 15.115234 6.71875 C 13.041234 6.71875 11.621094 7.9845938 11.621094 10.308594 L 11.621094 12.314453 L 9.2773438 12.314453 L 9.2773438 15.039062 L 11.621094 15.039062 L 11.621094 19 L 5 19 L 5 5 z" />
                                </svg>
                            </a>
                                            </div>
                </div>
            </div>
            <!-- end row -->
        </div>
        <!-- end container -->
    </div>
</footer>        <!-- end footer -->

        
    <script src="https://www.tieppoautomoveis.com.br/js/bootstrap.min.js"></script>
    <script src="https://www.tieppoautomoveis.com.br/js/jquery.inview.min.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js?v=3.exp"></script>
    <script src="https://www.tieppoautomoveis.com.br/js/tweetie/tweetie.min.js"></script>
    <script src="https://www.tieppoautomoveis.com.br/js/flexslider/jquery.flexslider-min.js"></script>
    <script src="https://www.tieppoautomoveis.com.br/js/owl.carousel.min.js"></script>
    <script src="https://www.tieppoautomoveis.com.br/js/isotope.pkgd.min.js"></script>
    <script src="https://www.tieppoautomoveis.com.br/js/imagesloaded.pkgd.min.js"></script>
    <script src="https://www.tieppoautomoveis.com.br/js/jquery.nouislider.all.min.js"></script>
    <script src="https://www.tieppoautomoveis.com.br/js/scripts.js"></script>

        <!--<script type="text/javascript" src="https://code.jquery.com/jquery-latest.min.js"></script>-->
<script src="//code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
<script src="js/jquery.min.js" type="text/javascript"></script>
<script src="js/jquery.flexslider.js" type="text/javascript"></script>
<script src="js/bootstrap.min.js" type="text/javascript"></script>
<script src="js/bootstrap-multiselect.js" type="text/javascript"></script>
<script src="js/init.js"></script> <!-- All Scripts -->
<script src="js/bootstrap-slider.js"></script> <!-- All Scripts -->
<script src="js/search.js"></script> <!-- All Scripts -->
<script src="js/pagination.js"></script> <!-- All Scripts -->
<script src="js/dealers.form.js"></script>
<script src="js/inputmask.js" type="text/javascript"></script>
<script src="js/jquery.inputmask.js" type="text/javascript"></script>
<script src="js/inputmask.numeric.extensions.js" type="text/javascript"></script>
<script src="js/inputmask.extensions.js" type="text/javascript"></script>
<script src="js/jquery.colorbox-min.js" type="text/javascript"></script>





<script>
	$('.mask-ano').inputmask('9999');
	$('.mask-preco').inputmask("decimal",{'autoUnmask' : true, radixPoint:",", groupSeparator: ".", digitsOptional: false, digits: 2, autoGroup: true, prefix: 'R$ '});
	$('.mask-fone').inputmask('(99) 9999-9999[9]');
	$('input[name=rg]').inputmask('9999999999999[9999]');
	//$('.mask-numeros').inputmask('[999999999999999999999999]');

	$('.mask-data').inputmask('99/99/9999');

	//$('input[name=ano]').inputmask('9999/9999');
	$('input[name=kilometragem]').inputmask('999.999 Km');
	$('input[name=date]').inputmask('99/99/9999');
	$('input[name=data]').inputmask('99/99/9999');
	$('input[name=ano]').inputmask('9999');
	$('input[name=portas]').inputmask('9');
	$('input[name=phone]').inputmask('(99) 9999-9999[9]');
	$('input[name=celular]').inputmask('(99) 9999-9999[9]');
	$('input[name=placa]').inputmask('aaa 9999');
	$('input[name=cpf]').inputmask('999.999.999-99');
	$('input[name=cep]').inputmask('99999-999');
	$('input[name=hora]').inputmask('99:99');
	// $('input[name=email]').inputmask('email');
	$('input.number').inputmask('999999999[9999]');
</script>
<!--Colorbox-->
<script>
    jQuery(document).ready(function () {
        jQuery('a.gallery').colorbox({ opacity:0.5 , rel:'group1' });
    });
</script>

<script>
	$("#year_min").val("");
	$("#year_max").val("");

	$("#ex1").slider({}).on("slideStop", function(){
		var _minValue = $("#ex1").slider('getValue')[0];
		var _maxValue = $("#ex1").slider('getValue')[1];
		var _str = "price+max_" + _maxValue + "-price+min_" + _minValue;

		$("#price").val(_str);
	});

	 $("#ex2").slider({}).on("slideStop", function(){
		var _minValue = $("#ex2").slider('getValue')[0];
		var _maxValue = $("#ex2").slider('getValue')[1];

		//var _ymax = "-year+model+max_" + _maxValue;
		//var _ymin = "-year+model+min_" + _minValue;

		$("#year_min").val(_minValue);
		$("#year_max").val(_maxValue);
	});

	$(window).load(function() {
	  $('#carousel').flexslider({
       animation: "slide",
       controlNav: false,
       animationLoop: false,
       slideshow: false,
       itemWidth: 210,
       itemHeight: 150,
       itemMargin: 5,
       asNavFor: '#slider'
   });

   $('#slider').flexslider({
       animation: "fade",
       controlNav: false,
       animationLoop: false,
       slideshow: false,
       sync: "#carousel"
   });
	});

	$('.thumb-gallery .slides .slider_item a').click(function(){
		var image = $(this).attr('getImage');
		$('.first-image ul li img').attr('src' , 'https://www.negociecarros.com.br/fotos_g/'+image);
	});
	  $('.example-multiple-selected').multiselect({

		onDropdownShown: function(e) {
			adjustByScrollHeight();
		},
		onDropdownHidden: function(e) {
			adjustByHeight();
		}
	});
	function adjustByHeight() {
        var $body   = $('body'),
            $iframe = $body.data('iframe.fv');
        if ($iframe) {
            // Adjust the height of iframe when hiding the picker
            $iframe.height($body.height());
        }
    }

    function adjustByScrollHeight() {
        var $body   = $('body'),
            $iframe = $body.data('iframe.fv');
        if ($iframe) {
            // Adjust the height of iframe when showing the picker
            $iframe.height($body.get(0).scrollHeight);
        }
    }

	$('.fmarks').hide();
	$('.marksect a label input').click(function(){
		var id = $(this).val();
		//alert(id);
		$('.fmarks').hide();
		$('.mark'+id).show();
	});

</script>
</body>

</html>